# -*- coding: utf-8 -*-
"""
Created on Mon Dec 25 17:37:01 2023

@author: Prince Kumar Gupta
"""

import streamlit as st
import pandas as pd
import numpy as np

st.title("my_sample_app")